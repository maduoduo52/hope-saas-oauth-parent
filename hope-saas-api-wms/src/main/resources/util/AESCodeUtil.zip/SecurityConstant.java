package com.hope.saas.common.constants;

/**
 * @author Maduo
 * @date 2020/3/24 10:10
 */
public class SecurityConstant {

    /**
     * 偏向量 AES_key  加密或者解密使用
     */
    public static String SECURITY_AES_KEY = "1234567890abcdef";
}
